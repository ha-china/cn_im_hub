import type { WeixinApiOptions } from "../api/api.js";
import type { MessageItem } from "../api/types.js";
import { MessageItemType } from "../api/types.js";
import { logger } from "../util/logger.js";

import { sendMessageItemWeixin } from "./send.js";

export type WeixinReplyProgressSenderDeps = {
  runId: string;
  to: string;
  accountId: string;
  opts: WeixinApiOptions & {
    contextToken?: string;
    runId?: string;
    accountId?: string;
  };
};

type ToolItemEventPayload = {
  itemId?: string;
  kind?: string;
  title?: string;
  name?: string;
  phase?: string;
  status?: string;
};

function normalizeToolStatus(status?: string): string {
  if (status === "completed") return "completed";
  if (status === "failed") return "failed";
  if (status === "blocked") return "blocked";
  return "unknown";
}

const MAX_CONSECUTIVE_TOOL_SEND_FAILURES = 3;

export class WeixinReplyProgressSender {
  readonly runId: string;

  private readonly to: string;
  private readonly accountId: string;
  private readonly opts: WeixinReplyProgressSenderDeps["opts"];
  private finalized = false;
  private sendChain: Promise<void> = Promise.resolve();
  private consecutiveToolSendFailures = 0;
  private toolProgressDisabled = false;

  constructor(deps: WeixinReplyProgressSenderDeps) {
    this.runId = deps.runId;
    this.to = deps.to;
    this.accountId = deps.accountId;
    this.opts = { ...deps.opts, runId: deps.runId, accountId: deps.accountId };
  }

  get replyOptions() {
    return {
      runId: this.runId,
      onItemEvent: (payload: ToolItemEventPayload) => this.handleToolItemEvent(payload),
    };
  }

  private enqueueMessage(item: MessageItem, label: string): void {
    if (this.finalized || this.opts.abortSignal?.aborted) return;
    this.sendChain = this.sendChain
      .then(async () => {
        if (this.toolProgressDisabled || this.opts.abortSignal?.aborted) return;
        await sendMessageItemWeixin({
          to: this.to,
          item,
          opts: this.opts,
          label,
        });
        this.consecutiveToolSendFailures = 0;
      })
      .catch((err) => {
        this.consecutiveToolSendFailures += 1;
        if (
          !this.toolProgressDisabled &&
          this.consecutiveToolSendFailures >= MAX_CONSECUTIVE_TOOL_SEND_FAILURES
        ) {
          this.toolProgressDisabled = true;
          logger.warn(
            `tool progress disabled for runId=${this.runId} accountId=${this.accountId} after ${this.consecutiveToolSendFailures} consecutive send failures; lastErr=${String(err)}`,
          );
        }
        logger.warn(
          `${label}: failed to=${this.to} accountId=${this.accountId} runId=${this.runId} err=${String(err)}`,
        );
      });
  }

  private handleToolItemEvent(payload: ToolItemEventPayload): void {
    if (this.finalized || this.opts.abortSignal?.aborted) return;
    if (this.toolProgressDisabled) return;
    if (payload.kind !== "tool") return;
    if (payload.phase !== "start" && payload.phase !== "end") return;

    const now = Date.now();
    const toolName = payload.name?.trim() || payload.title?.trim() || "tool";
    const toolCallId = payload.itemId?.trim() || undefined;

    if (payload.phase === "start") {
      this.enqueueMessage(
        {
          type: MessageItemType.TOOL_CALL_START,
          create_time_ms: now,
          is_completed: false,
          tool_call_start_item: {
            tool_name: toolName,
            tool_call_id: toolCallId,
          },
        },
        "sendToolCallStartMessage",
      );
      return;
    }

    this.enqueueMessage(
      {
        type: MessageItemType.TOOL_CALL_RESULT,
        create_time_ms: now,
        is_completed: true,
        tool_call_result_item: {
          tool_name: toolName,
          tool_call_id: toolCallId,
          status: normalizeToolStatus(payload.status),
        },
      },
      "sendToolCallResultMessage",
    );
  }

  async finalize(): Promise<void> {
    if (this.finalized) return;
    this.finalized = true;
    try {
      await this.sendChain;
    } catch (err) {
      logger.warn(
        `WeixinReplyProgressSender.finalize: send drain failed runId=${this.runId} err=${String(err)}`,
      );
    }
  }
}
